//
//  home.swift
//  WooCommerce
//
//  Created by pearl on 15/07/2022.
//

import SwiftUI
import Foundation
import SDWebImage
import SDWebImageSwiftUI
struct home: View {
    let screenSize = UIScreen.main.bounds.size;
    @State var loggedIn:Bool = false;
    @State private var uname = ""
    @State private var password=""
    @State private var secured: Bool = true

    @State private var toast = false
    @State private var toast_message = ""
    @State private var login_pressed = false
    @State private var animations = false
    @State private var categ_button = false;
    @State var data1 :[Categories.VCategories] = []
    @State var product_data :[Products.VProducts] = []
    @State var product_image_data :[AllProducts.VAllProducts] = []
    @State var product_image :[AllProducts] = []
    @ObservedObject private var Functions = fnctions()
    /// code wil move to another function view/////
  func loadData() {

         guard let url = URL(string:Constants.Url.CategoriesList)
        else {
             print("Invalid URL")
             return
         }
         
       
   
      // Prepare URL Request Object
      var request = URLRequest(url: url)
      request.httpMethod = "POST"



      
      let postString = "";
      request.httpBody = postString.data(using:.utf8);
      // Perform HTTP Request
      let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

              // Check for Error
              if let error = error {
                  print("Error took place \(error)")
                  return
              }

              // Convert HTTP Response Data to a String
          let dataString = String(data: data!, encoding: .utf8)
          print(dataString)

          
          //
          
         //
          
          do {
              let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
           print(myServiceResponse)
           
         DispatchQueue.main.async {
            self.data1 = myServiceResponse.categories
        
          
             


         }
     } catch let error {
        // self.newData = []
         
//         self.data2 = []
        
     }
          
      }
      task.resume()

  }
    /// code wil move to another function view/////
    func loadProducts(){
         

                guard let url = URL(string:Constants.Url.Products_By_Category_Id)
               else {
                    print("Invalid URL")
                    return
                }
                
              
          
             // Prepare URL Request Object
             var request = URLRequest(url: url)
             request.httpMethod = "POST"


         let category_id = (UserDefaults.standard.string(forKey: "categ_id") ?? "its string")!;
//          let postString: [String: Any] = [
//              "id": category_id,
//
//          ]
      
         
       let postString = category_id;
        
        //
         request.httpBody = postString.data(using: String.Encoding.utf8);
             // Perform HTTP Request
             let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                     // Check for Error
                     if let error = error {
                         print("Error took place \(error)")
                         return
                     }

                     // Convert HTTP Response Data to a String
                 let dataString = String(data: data!, encoding: .utf8)
                 print(dataString)


                 //
                 
                //
                 
                 do {
                     let myServiceResponse = try JSONDecoder().decode(Products.self,from: data!)
                  print(myServiceResponse)
                   
                  
                DispatchQueue.main.async {
                   self.product_data = myServiceResponse.data
               
                 
                    


                }
            } catch let error {
               // self.newData = []
                
                self.product_data = []
               
            }
                 
             }
             task.resume()

         
    }
    /// code wil move to another function view/////
    func loadProductImage(){
         

                guard let url = URL(string:Constants.Url.allproduct)
               else {
                    print("Invalid URL")
                    return
                }
                
              
          
             // Prepare URL Request Object
             var request = URLRequest(url: url)
             request.httpMethod = "POST"


         let product_id = (UserDefaults.standard.string(forKey: "product_id") ?? "its string")!;
//          let postString: [String: Any] = [
//              "id": category_id,
//
//          ]
      
         
       let postString = product_id;
        
        //
         request.httpBody = postString.data(using: String.Encoding.utf8);
             // Perform HTTP Request
             let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                     // Check for Error
                     if let error = error {
                         print("Error took place \(error)")
                         return
                     }

                     // Convert HTTP Response Data to a String
                 let dataString = String(data: data!, encoding: .utf8)
                 print(dataString)


                 //
                 
                //
                 
                 do {
                     let myServiceResponse = try JSONDecoder().decode(AllProducts.self,from: data!)
                  print(myServiceResponse)
                   
                  
                DispatchQueue.main.async {
                   self.product_image_data = myServiceResponse.data
               
                 
                    


                }
            } catch let error {
               // self.newData = []
                
                self.product_image_data = []
               
            }
                 
             }
             task.resume()

         
    }
  
    var body: some View {
    
        NavigationView{
            ZStack{
                Color.purple
                    .ignoresSafeArea(.all)
                
                
                
                VStack
                {
                    ZStack{
                        Color.white
                            .frame(width: screenSize.width*0.92, height: screenSize.height*0.75)
                            .cornerRadius(60)
                            .padding(.bottom,95)
                        VStack(spacing:10)
                        {
//                                         Divider()
                            HStack{
                                VStack
                                  {
                                      
                                      Image(systemName: "square.grid.3x3")
                                          .resizable()
                                          .scaledToFit()
                                          .clipped()
                                          .frame(width: 22, height: 30)
                                          
                                          
                                      Text("Categories")
                                      .foregroundColor(Color.purple)
                                      .font(.system(size:10))
                                  }
                                  //.frame(width: 70,height: 70)
                              
                                  
                                
                               

                           
                                  ScrollView(.horizontal,showsIndicators: true){
                                      
                                      HStack{
                                      ForEach(data1, id: \.id) { item in
                                      Button {
                                                    print("Image tapped!")
                                                  loadProducts()
                                         // Functions.loadProducts()
                                                  let categ_id = item.id! ;
                                                  UserDefaults.standard.set(categ_id, forKey: "categ_id");
                                                  self.categ_button = true;
                                                  } label: {
                            let img_shw = URL(string:item.image ?? "No image")
                                VStack{
                                    if (item.image == "")
                                    {Image(systemName: "square")
                                            .resizable()
                                            .scaledToFit()
                                            .clipped()
                                           .frame(width: 25, height: 30)
                                           .foregroundColor(Color.purple)
                                        Text(item.name ?? "No text")
                                        .font(.system(size:10))
                                        .foregroundColor(Color.purple)
                                        
                                    }
                                    else{
                                        WebImage(url: (img_shw))
                                        .resizable()
                                        .scaledToFit()
                                        .clipped()
                                       .frame(width: 25, height: 30)
                                       .foregroundColor(Color.purple)
                                       Text(item.name ?? "No text")
                                       .font(.system(size:10))
                                       .foregroundColor(Color.purple)
                                         }
                                     }.padding([.trailing,.leading],10)
                                                   } }
                                      }
                                          
                                      .onAppear(perform: loadData)
                                      
                                  }.frame(height: 100)
                                    
                                      
                               
//                                      List(CategoriesListAPI.dataList)
//                                      {
//                                          model in CategoriesListView(model:model,dataList:CategoriesListAPI.dataList)
//
//                                      }

//                                       }.frame(height: 10)
//                                         Divider()
//                                         Spacer()
                              
                            }
                            .frame(width: screenSize.width*0.85, height: screenSize.height*0.05,alignment:.top)
//                                .font(.system(size:25))
                               
                        .foregroundColor(Color.purple)
                            // .padding(.bottom,450)
                            Spacer()
                            
                            
                            
                            VStack{
            
                            
                                ForEach(product_image_data,id: \.id){
                                    banners in
                                    
                                    Text((banners.name)!)
                                        .foregroundColor(Color.purple)
                                        .font(.system(size:15))
                                    
                                    
                                    
                                   
                                    
                                    
                                    
                                    
                                    
                                }
                               
                        
                                
                                
                                
                                
                                
                            }
                           
                            .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                            
                            
                            
                            Spacer()
                           
                            
                            
                            //                                        Spacer()
                            
                            VStack(spacing:10){
                                
                              
                                Text("Trending Now")
                                    .font(.system(size:25,weight:.bold))
                                    .padding(.trailing,170)
                                  
                                 
                                   
                                if(self.categ_button == true)
                                {
                                    
                                   
//                                    NavigationLink("h", destination: products())
                                    /// code wil move to another products view/////
                                    
                                     
                                        
                                        ScrollView(.horizontal,showsIndicators: true){
                                            
                                        HStack{
                                        ForEach(product_data, id: \.id) { product in
                                       
                                    

                                           
                                                
                                                Button {
                                                         print("Image tapped!")
                                                    
                                                    /// code wil move to another allproducts view/////
                                                    loadProductImage()
                                                   // Functions.loadProductImage()
                                                    let product_id = product.id!;
                                                    UserDefaults.standard.set(product_id, forKey: "product_id");
                                                   
                                                   
                                                    
                                                    
                                                    
                                                    
                                                    ///

                                                     } label: {
                                                         
                                  VStack{
 
                                      let product_img = product.image!;
                                      WebImage(url: (URL(string: product_img)))
                                      .resizable()
                                      .scaledToFit()
                                      .clipped()
                                     .frame(width: 30, height: 45)
                                     .foregroundColor(Color.purple)
                                    
                                      Text(product.title ?? "No")
                                     .font(.system(size:10))
                                     .foregroundColor(Color.purple)
                                    }.frame(height: 100)
                                                     }
                                        }.padding([.trailing,.leading],16)
                                        }
                                 }
                                        
                                        
                                        
                                        
                                        
                                    
                                    //////////////////
                                    
                                    
                                }
                                else{
                                    Text("bottom")
                                }
                               
                               
                       
                               }
                            .frame(width: screenSize.width*0.85, height: screenSize.height*0.05)
                            
                            Spacer()
                          
                            
                        }
                        
                    }
                    
                    
                    
                }
                
                
                
                
            }
          
                
            
            .toolbar {
                ToolbarItem() {
                    HStack(spacing:255)
                    {
                        Button(
                            action:
                                {
                                    login_pressed = true
                                    //                                    self.login()
                                    
                                }
                        )
                        {
                            
                            Text("Home")
                                .foregroundColor(Color.white)
                                .font(.system(size:20,weight: .bold))
                         }
                        
                        Button(
                            action:
                                {
                                    login_pressed = true
                                    //                                    self.login()
                                    
                                }
                        )
                        {
                            
                            Image(systemName: "magnifyingglass")
                            
                                .foregroundColor(Color.white)
                                .font(.system(size:20,weight: .bold))
                            
                            
                        }
                        
                        
                    }.padding(.bottom,25)
                    
                    
                    
                    
                }
                ToolbarItem(placement: .bottomBar) {
                    
                    HStack(spacing:20){
                        
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Home")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Categories")
                                .font(.system(size:10.7))
                        }
                      
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Orders")
                                .font(.system(size:12))
                        }
                      
                      
                        VStack{
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "person.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        
                       
                        
                    }
                    
                    .foregroundColor(Color.white)
                    
                    
                    
                }
                
            }
            
            
            
            
            
            
        }
     
        
        
    }
   
}

struct home_Previews2: PreviewProvider {
    static var previews: some View {
        home()
    }
}

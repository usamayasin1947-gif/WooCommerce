//
//  Register.swift
//  WooCommerce
//
//  Created by pearl on 15/07/2022.
//

import SwiftUI
import AlertToast

struct Register: View {
    let screenSize = UIScreen.main.bounds.size;
    @State var loggedIn:Bool = false;
    @State private var fname = "";
    @State private var lname = "";
    @State private var uname = "";
    @State private var password="";
    @State private var cnfrm_password="";
    @State private var pasword_matched_message = ""
    @State private var address = "";
    @State private var phone = "";
    @State private var email="";
    @State private var secured: Bool = true
    @State private var password_toast  = false
     
     @State private var fields_toast = false;
     @State private var fields_toast_message = ""
    @State private var toast = false
    @State private var toast_message = ""
    @State private var register_toast = false
    @State private var register_pressed = false
    @State private var regiter_success_message = ""
    @State private var regiter_fail_message = ""
    @State private var animations = false

            func register(){
    
//                self.register_pressed = true;
                let Username = UserDefaults.standard.string(forKey: "user_name") ?? "";
                let Password = UserDefaults.standard.string(forKey: "password") ?? "";
                let Confirm_password = UserDefaults.standard.string(forKey: "confirm_password") ?? "";
                let Email = UserDefaults.standard.string(forKey: "email") ?? "";
                
                let FirstName = UserDefaults.standard.string(forKey: "first_name") ?? "";
                
                let LastName = UserDefaults.standard.string(forKey: "last_name") ?? "";
                let Phone = UserDefaults.standard.string(forKey: "phone") ?? "";
                
                let Address = UserDefaults.standard.string(forKey: "address") ?? "";
                
                
//                if (self.Password == self.Confirm_password)
//                {
//
//
//
//
//                }
                
                guard let url = URL(string:Constants.Url.register_api)
               else {
                    print("Invalid URL")
                  
                   
                    return
                }
    
    
    
             // Prepare URL Request Object
             var request = URLRequest(url: url)
             request.httpMethod = "POST"
    
    
             
              //  UserDefaults.standard.string(forKey: String)
               
               
                

let postString = "username="+Username+"&email="+Email+"&password="+Password+"&first_name="+FirstName+"&last_name="+LastName+"&address="+Address+"&phone="+Phone;
                //let postString2 = "last_name="+Lastname+"&address="+Address+"&phone="+Phone;
               // let postString = postString1+"&"+postString2;
 //               let postString2: [String: Any] = ["username": Username, "email": Email,"password": Password];

//                let postString = "";
             request.httpBody = postString.data(using:.utf8);
             // Perform HTTP Request
             let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in
    
                     // Check for Error
                     if let error = error {
                         print("Error took place \(error)")
                         self.register_toast = true ;
                         self.regiter_fail_message = "Please Correctly fill all fields"
                         return
                     }
    
                     // Convert HTTP Response Data to a String
                 let dataString = String(data: data!, encoding: .utf8)
                 print(dataString)
    
    
                 //
    
                //
    
                 do {
//                     let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
//                  print(myServiceResponse)
    
                DispatchQueue.main.async {
                  // self.data1 = myServiceResponse.categories
    
                    self.register_toast = true ;
                    self.regiter_success_message = "You have successfully registered";
    
    
    
                }
            } catch let error {
               // self.newData = []
    
       //         self.data2 = []
    
            }
    
             }
             task.resume()
    
    
    
            }
    var body: some View {
       


        
            NavigationView{
                ZStack{
                    Color.purple
                        .ignoresSafeArea(.all)
                    
                    
                    
                    VStack
                    {
                        
                        //
                        
                        //
                        //                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05,alignment: .topLeading)
                        
                        
                        
                        
                        
                        
//                        Image(systemName: "cart.circle")
//
//                            .font(.system(size: 75))
//                            .padding(.bottom,0.1)
//                        Text("WO")
//                            .foregroundColor(Color.black)
//                            .font(.system(size: 35,weight:.bold))
//                        +
//                        Text(" ")
//
//                        +
//                        Text("STORE")
//                            .foregroundColor(Color.white)
//                            .font(.system(size: 35,weight:.bold))
//
                        
                        ZStack{
                            Color.white
                                .frame(width: screenSize.width*0.92, height: screenSize.height*0.75)
                                .cornerRadius(60)
                                .padding(.bottom,60)
                            VStack(spacing:15)
                            {
                                
                                Text("Register here")
                                    .foregroundColor(Color.purple)
                                    .font(.system(size: 20,weight:.bold))
                                    .padding([.bottom,.top],5)
//                                ScrollView([.horizontal, .vertical]) {
                                    VStack{
                                        
                                        
                                        HStack{
                                            
                                            Image(systemName: "person.fill")
                                            TextField("First Name", text: $fname)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                                .foregroundColor(.gray)
                                            
                                        }
                                        .padding(.horizontal, 49)
                                        .padding(.bottom,2)
                                        //                                                .padding(.top, 20)
                                        
                                        
                                        
                                        Divider()
                                            .padding(.horizontal, 50)
                                        
                                        
                                        
                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                    VStack{
                                        
                                        
                                        HStack{
                                            
                                            Image(systemName: "person.fill")
                                            TextField("Last Name", text: $lname)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                                .foregroundColor(.gray)
                                            
                                        }
                                        .padding(.horizontal, 49)
                                        .padding(.bottom,2)
                                        //                                                .padding(.top, 20)
                                        
                                        
                                        
                                        Divider()
                                            .padding(.horizontal, 50)
                                        
                                        
                                        
                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                ///
                                        VStack{
                                
                                
                                HStack{
                                    
                                    Image(systemName: "person.fill")
                                    TextField("User Name", text: $uname)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                        .foregroundColor(.gray)
                                    
                                }
                                .padding(.horizontal, 49)
                                .padding(.bottom,2)
                                //                                                .padding(.top, 20)
                                
                                
                                
                                Divider()
                                    .padding(.horizontal, 50)
                                
                                
                                
                
                                
                                
                                
                                
                                
                            }
                            .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                ///
                                
                                    VStack{
                                        
                                        
                                        HStack{
                                            
                                            Image(systemName: "house.fill")
                                            TextField("Address", text: $address)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                                .foregroundColor(.gray)
                                            
                                        }
                                        .padding(.horizontal, 49)
                                        .padding(.bottom,2)
                                        //                                                .padding(.top, 20)
                                        
                                        
                                        
                                        Divider()
                                            .padding(.horizontal, 50)
                                        
                                        
                                        
                        
                                        
                                        
                                        
                                        
                                        
                                    }
                                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                VStack{
                                    
                                    
                                    HStack{
                                        
                                        Image(systemName: "phone.fill")
                                        TextField("Phone", text: $phone)
                                            .autocapitalization(.none)
                                            .disableAutocorrection(true)
                                            .foregroundColor(.gray)
                                        
                                    }
                                    .padding(.horizontal, 49)
                                    .padding(.bottom,2)
                                    //                                                .padding(.top, 20)
                                    
                                    
                                    
                                    Divider()
                                        .padding(.horizontal, 50)
                                    
                                    
                                    
                    
                                    
                                    
                                    
                                    
                                    
                                }
                                .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                
                               ////
                                VStack{
                                    
                                    HStack{
                                        
                                        Image(systemName: "envelope.fill")
                                        TextField("Email Address", text: $email)
                                            .autocapitalization(.none)
                                            .disableAutocorrection(true)
                                            .foregroundColor(.gray)
                                        
                                    }
                                    .padding(.horizontal, 49)
                                    .padding(.bottom,2)
                                    //                                                .padding(.top, 20)
                                    
                                    
                                    
                                    Divider()
                                        .padding(.horizontal, 50)
                                    
                                    
                                    
                    
                                    
                                    
                                    
                                    
                                    
                                }
                                .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                ///
                                
                                
                                VStack{
                                    HStack{
                                       if secured {
                                           // 2
                                            Image(systemName: "lock.fill")
                                            SecureField("Password", text: $password)
                                            
                                                .foregroundColor(.gray)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                        } else {
                                            
                                            // 3
                                            Image(systemName: "lock.fill")
                                            
                                            TextField("Password", text: $password)
                                            
                                                .foregroundColor(.gray)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                        }
                                 
                                          Button(action: {
                                            self.secured.toggle()
                                        }) {
                                            
                                            // 2
                                            if secured {
                                                Image(systemName: "eye.slash.circle")
                                                    .font(.system(size:12))
                                                    .foregroundColor(Color.black
                                                    )
                                            } else {
                                                
                                                Image(systemName: "eye.circle")
                                                    .font(.system(size:12))
                                                    .foregroundColor(Color.black
                                                    )
                                            }
                                        }
                                         
                                    }
                                    
                                    .padding(.horizontal, 49)
                                    .padding(.bottom,2)
                                    //                                    .padding(.top, 20)
                                     Divider()
                                        .padding(.horizontal, 50)
                                    ////////////////////
                                    
                                    
                                }
                                .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                
                                
                                VStack{
                                    HStack{
                                       if secured {
                                           // 2
                                            Image(systemName: "lock.fill")
                                            SecureField("Confirm Password", text: $cnfrm_password)
                                            
                                                .foregroundColor(.gray)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                        } else {
                                            
                                            // 3
                                            Image(systemName: "lock.fill")
                                            
                                            TextField("Confirm Password", text: $cnfrm_password)
                                            
                                                .foregroundColor(.gray)
                                                .autocapitalization(.none)
                                                .disableAutocorrection(true)
                                        }
                                 
                                          Button(action: {
                                            self.secured.toggle()
                                        }) {
                                            
                                            // 2
                                            if secured {
                                                Image(systemName: "eye.slash.circle")
                                                    .font(.system(size:12))
                                                    .foregroundColor(Color.black
                                                    )
                                            } else {
                                                
                                                Image(systemName: "eye.circle")
                                                    .font(.system(size:12))
                                                    .foregroundColor(Color.black
                                                    )
                                            }
                                        }
                                         
                                    }
                                    
                                    .padding(.horizontal, 49)
                                    .padding(.bottom,2)
                                    //                                    .padding(.top, 20)
                                     Divider()
                                        .padding(.horizontal, 50)
                                    ////////////////////
                                    
                                    
                                }
                                .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                        

//                                }
//                                .frame(height:200, alignment: .center)
                             
//                                .tabViewStyle(PageTabViewStyle())
//                                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                                
                                //                                        Spacer()
                                
                              VStack(spacing:20){
                                    
                        
                                    
                                    Text("Your personal data will be used to support your experience throughout this webiste,to manage access to your account,and for other purposes describe in our privacy policy.")
                                        .font(.system(size:12))
                                        .padding(.horizontal, 50)
                                        .padding(.top,-5)
                                        
                                       
                                    Button(action:{
                                        if(password != cnfrm_password)
                                        {
                                            self.password_toast = true;
                                            
                                            self.pasword_matched_message = "Password and Confirm Password must be same";
                                        }
                                        else{
                                            register_pressed = true
                                            //                                    self.login()
                                         
                                           
                                            UserDefaults.standard.set(uname, forKey: "user_name")
                                            UserDefaults.standard.set(password, forKey: "password")
                                            UserDefaults.standard.set(cnfrm_password, forKey: "confirm_password")
                                            UserDefaults.standard.set(email, forKey: "email")
                                            
                                            UserDefaults.standard.set(fname, forKey: "first_name")
                                            UserDefaults.standard.set(lname, forKey: "last_name")
                                            UserDefaults.standard.set(phone, forKey: "phone")
                                            UserDefaults.standard.set(address, forKey: "address")
                                            
     
                                             if(fname.isEmpty && lname.isEmpty && uname.isEmpty && phone.isEmpty && email.isEmpty && address.isEmpty)
                                             {
                                                  self.fields_toast = true;
                                                  self.fields_toast_message = "Please Fill All the fields ";
                                          }
                                             else{
                                                  register()
                                                 
                                             }
                                                
                                          
                                           
   
                                            
                                            
                                        }
                             
                                       
                                    }
                                    ){
                                        
                                        
                                        Text("Register")
                                        
                                            .fontWeight(.bold)
                                            .foregroundColor(Color.white)
                                            .padding(.horizontal, 90)
                                            .padding()
                                            .background(Color.purple)
                                       
//                                        if (password_toast == true)
//                                        {
//                                            Text(pasword_matched_message )
//
//
//                                                .animation(.interpolatingSpring(stiffness: 5, damping: 1), value: password_toast)
//                                        }
                                     
                                       
                                    }
                                }
                                
                                .padding(.bottom,80)
                                
                            }
                            
                        }
                        
                        
                        
                    }
                    .toast(isPresenting: $password_toast){
                         
                         // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                     AlertToast(displayMode: .alert
                                , type: .regular ,title: pasword_matched_message)
                              
                      
                         //Choose .hud to toast alert from the top of the screen
                         //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                     }
                    .animation(.interpolatingSpring(stiffness: 15, damping: 15), value: password_toast)
                    .toast(isPresenting: $register_toast){
                         
                         // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                     AlertToast(displayMode: .hud
                                , type: .regular ,title: regiter_success_message)
                              
                      
                         //Choose .hud to toast alert from the top of the screen
                         //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                     }
                    .toast(isPresenting: $fields_toast){
                         
                         // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                     AlertToast(displayMode: .hud
                                , type: .regular ,title: fields_toast_message)
                              
                      
                         //Choose .hud to toast alert from the top of the screen
                         //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                     }

                    
                    
                    
                    
                }
//                .onAppear{
//
//                    self.fname = UserDefaults.standard.string(forKey: "first_name") ?? "";
//                    self.lname = UserDefaults.standard.string(forKey: "last_name") ?? "";
//                    self.uname = UserDefaults.standard.string(forKey: "user_name") ?? "";
//
//                    self.password = UserDefaults.standard.string(forKey: "password") ?? "";
//                    self.email = UserDefaults.standard.string(forKey: "email") ?? "";
//                    self.address = UserDefaults.standard.string(forKey: "address") ?? "";
//
//                    self.phone = UserDefaults.standard.string(forKey: "phone") ?? "";
//
//
//
//
//
//
//
//
//
//
//                }
                
                .toolbar {
                    ToolbarItem() {
                        HStack(spacing:270){
                            Button(
                                action:
                                    {
                                       
                                        //                                    self.login()
                                        
                                    }
                            )
                            {
                                
                                Image(systemName: "menucard.fill")
                                
                                    .foregroundColor(Color.white)
                                
                                
                            }
                            
                            
                            
                            
                            Button(
                                action:
                                    {
//                                        login_pressed = true
                                        //                                    self.login()
                                        
                                    }
                            )
                            {
                                
                                Image(systemName: "cart.fill")
                                
                                    .foregroundColor(Color.white)
                                
                                
                            }
                            
                            
                        }  .font(.system(size:25))
                        
                        
                        
                        
                    }
                    ToolbarItem(placement: .bottomBar) {
                        
                        HStack(spacing:20){
                            
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Home")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Categories")
                                    .font(.system(size:10.7))
                            }
                          
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Orders")
                                    .font(.system(size:12))
                            }
                          
                          
                            VStack{
                                Image(systemName: "questionmark.circle.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "person.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            
                           
                            
                        }
                        .foregroundColor(Color.white)
                  
                        
                        
                        
                        
                    }
                    
                }
                
                
                
                
                
                
            }
         
    }
}

struct Register_Previews2: PreviewProvider {
    static var previews: some View {
        Register()
    }
}

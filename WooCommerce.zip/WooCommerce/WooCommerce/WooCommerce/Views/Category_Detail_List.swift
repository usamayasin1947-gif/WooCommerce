//
//  Category_Detail_List.swift
//  WooCommerce
//
//  Created by pearl on 10/08/2022.
//

import SwiftUI
import SDWebImage
import SDWebImageSwiftUI
struct Category_Detail_List: View {
    
    let screenSize = UIScreen.main.bounds.size;
    @State var data1 :[Categories.VCategories] = []
    @ObservedObject private var Functions = fnctions()
    /// code wil move to another function view/////
  func loadData() {

         guard let url = URL(string:Constants.Url.CategoriesList)
        else {
             print("Invalid URL")
             return
         }
         
       
   
      // Prepare URL Request Object
      var request = URLRequest(url: url)
      request.httpMethod = "POST"



      
      let postString = "";
      request.httpBody = postString.data(using:.utf8);
      // Perform HTTP Request
      let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

              // Check for Error
              if let error = error {
                  print("Error took place \(error)")
                  return
              }

              // Convert HTTP Response Data to a String
          let dataString = String(data: data!, encoding: .utf8)
          print(dataString)

          
          //
          
         //
          
          do {
              let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
           print(myServiceResponse)
           
         DispatchQueue.main.async {
            self.data1 = myServiceResponse.categories
        
          
             


         }
     } catch let error {
        // self.newData = []
         
//         self.data2 = []
        
     }
          
      }
      task.resume()

  }
    var body: some View {
        
       
            NavigationView{
                ZStack{
                    Color.purple
                        .ignoresSafeArea(.all)
                    
                    
                    
                    VStack
                    {
                        ZStack{
                            Color.white
                                .frame(width: screenSize.width*0.92, height: screenSize.height*0.75)
                                .cornerRadius(60)
                                .padding(.bottom,95)
                            
                            
                            HStack{
                                
                                
                                VStack{
                                    
                                    
                                    
                                    ScrollView(.vertical,showsIndicators: true){
                                        
                                        VStack{
                                        ForEach(data1, id: \.id) { item in
                                        Button {
                                                      print("Image tapped!")
                                                    }
                                        label: {
                              let img_shw = URL(string:item.image ?? "No image")
                                            VStack(spacing:2)
                                            {
                                      if (item.image == "")
                                      {
                                          
                                          Image(systemName: "square")
                                              .resizable()
                                              .scaledToFit()
                                              .clipped()
                                             .frame(width: 25, height: 50)
                                             .foregroundColor(Color.purple)
                                          Text(item.name ?? "No text")
                                          .font(.system(size:13))
                                          .foregroundColor(Color.purple)
                                          
                                      }
                                      else{
                                          WebImage(url: (img_shw))
                                          .resizable()
                                          .scaledToFit()
                                          .clipped()
                                         .frame(width: 25, height: 50)
                                         .foregroundColor(Color.purple)
                                         Text(item.name ?? "No text")
                                         .font(.system(size:13))
                                         .foregroundColor(Color.purple)
                                           }
                                            }
                                            .padding([.bottom],20)
                                                     
                                        
                                        }
                                            
                                            
                                        }
                                       
                                        }
                                      
                                       
                                        
                                    } .onAppear(perform: loadData)
                                        .frame(width:130, height:450)
                                        .padding(.bottom,130)
                                    
                                    
                                    
                                }
                              
                           //     .padding(.trailing,10)
                                HStack{
                                    
                                    Divider()
                                    
                                }
                                .padding(.trailing,70)
                               
                               
                      //  .padding(.trailing,150)
                                VStack{
                                   
                                  
                                        
                                        Text("hello")
                                    
                                    
                                }
                                .frame(height:200)
                                .padding(.trailing,120)
                                
                            }
                            
                            
                            

                        }
                        
                        
                        
                    }
                    
                    
                    
                    
                }
              
                    
                
                .toolbar {
                    ToolbarItem() {
                        HStack
                        {
                            Button(
                                action:
                                    {
                                      //  login_pressed = true
                                        //                                    self.login()
                                        
                                    }
                            )
                            {
                                
                                Text("Categories")
                                    .foregroundColor(Color.white)
                                    .font(.system(size:20,weight: .bold))
                             }
                            
                        
                           
                            
                            
                        }.padding(.bottom,25)
                            .padding(.trailing,230)
                        
                        
                        
                        
                    }
                    ToolbarItem(placement: .bottomBar) {
                        
                        HStack(spacing:20){
                            
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Home")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Categories")
                                    .font(.system(size:10.7))
                            }
                          
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Orders")
                                    .font(.system(size:12))
                            }
                          
                          
                            VStack{
                                Image(systemName: "questionmark.circle.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "person.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            
                           
                            
                        }
                        
                        .foregroundColor(Color.white)
                        
                        
                        
                    }
                    
                }
                
                
                
                
                
                
            }
    }
}

struct Category_Detail_List_Previews: PreviewProvider {
    static var previews: some View {
        Category_Detail_List()
    }
}

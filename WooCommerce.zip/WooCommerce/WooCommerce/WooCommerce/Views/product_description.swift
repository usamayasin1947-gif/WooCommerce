//
//  product_description.swift
//  WooCommerce
//
//  Created by pearl on 04/08/2022.
//

import SwiftUI

struct product_description: View {
    let screenSize = UIScreen.main.bounds.size;
    var body: some View {
//        NavigationView{
//
////            VStack(alignment:.center){
////
////                Image(systemName: "square")
////                        .resizable()
////                        .scaledToFit()
////                        .clipped()
////
////                       .foregroundColor(Color.purple)
////
////
////
////            }
////
////            .frame(width: 300, height: 500,alignment: .top)
////            .padding(.bottom,300)
//
//
//
//
//
//
//
//        }
        NavigationView{
            ZStack{
                Color.purple
                    .ignoresSafeArea(.all)
                
                
                
                VStack
                {
                    ZStack{
                        Color.white
                            .frame(width: screenSize.width*0.92, height: screenSize.height*0.75)
                            .cornerRadius(60)
                            .padding(.bottom,95)
                        VStack(spacing:10)
                        {
//                                         Divider()
                         
                                 
                            VStack(alignment:.center, spacing:10)
                            {
                                
                                                Image(systemName: "square")
                                                        .resizable()
                                                        .scaledToFit()
                                                        .clipped()
                                
                                                       .foregroundColor(Color.purple)
                                                       .frame(width: 250, height: 300)
                                
                                
                                            
                                
                                          
                                          //  .padding(.bottom,200)
                                
                               

                                VStack{
                                    Text("Similar Images")
                                        .padding(.trailing,200)
                                    
                                    HStack(spacing:20)
                                    {
                                        
                                        Image(systemName: "figure.walk")
                                        Image(systemName: "figure.walk")
                                        Image(systemName: "figure.walk")
                                        Image(systemName: "figure.walk")
                                        Image(systemName: "figure.walk")
                                        Image(systemName: "figure.walk")
                                        
                                        
                                    }
                                    
                                    
                                }
                               
                                
                                VStack{
                                    
                                    HStack{
                                        Text("RS:4000")
                                    
                                       
                                        Text("RS:4000")
                                            
                                        
                                    } .padding(.trailing,170)
                                   
                                    HStack{
                                        Text("100 Rs Discount on First Delivery")
                                        .padding(.leading,10)
                                        
                                        HStack{
                                            Text("3.6")
                                            Image(systemName: "asterisk")
                                            
                                        }.padding(10)
                                         .background(Color.yellow)
                                         .cornerRadius(15)
                                        
                                         }
                                    
                                    Divider()
                                    
                                    
                                    Divider()
                      
                                }
                              
                                  
                                
                               
                                
                                    
                                    
                                    
                              
                                
                                
                                
                                
                                }
                                    
                                      
                        
                            
//                            .frame(width: screenSize.width*0.85, height: screenSize.height*0.05,alignment:.top)
//                                .font(.system(size:25))
                               
                        .foregroundColor(Color.purple)
                            // .padding(.bottom,450)
                            Spacer()
                            
                            
                            
                            VStack{
            
                         
                               
                        
                                
                                
                                
                                
                                
                            }
                           
                            .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                            
                            
                            
                            Spacer()
                           
                            
                            
                            //                                        Spacer()
                            
                            VStack(spacing:10){
                                
                              
                                Text("Trending Now")
                                    .font(.system(size:25,weight:.bold))
                                    .padding(.trailing,170)
                                  
                                 
                                   
                 
                               
                               
                       
                               }
                            .frame(width: screenSize.width*0.85, height: screenSize.height*0.05)
                            
                            Spacer()
                          
                            
                        }
                        
                    }
                    
                    
                    
                }
                
                
                
                
            }
   
                 
            
            .toolbar {
                ToolbarItem() {
                    HStack(spacing:255)
                    {
                        Button(
                            action:
                                {
                                    
                                    //                                    self.login()
                                    
                                }
                        )
                        {
                            
                            Text("Home")
                                .foregroundColor(Color.white)
                                .font(.system(size:20,weight: .bold))
                         }
                        
                        Button(
                            action:
                                {
                                   
                                    //                                    self.login()
                                    
                                }
                        )
                        {
                            
                            Image(systemName: "magnifyingglass")
                            
                                .foregroundColor(Color.white)
                                .font(.system(size:20,weight: .bold))
                            
                            
                        }
                        
                        
                    }.padding(.bottom,25)
                    
                    
                    
                    
                }
                ToolbarItem(placement: .bottomBar) {
                    
                    HStack(spacing:20){
                        
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Home")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Categories")
                                .font(.system(size:10.7))
                        }
                      
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Orders")
                                .font(.system(size:12))
                        }
                      
                      
                        VStack{
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "person.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        
                       
                        
                    }
                    
                    .foregroundColor(Color.white)
                    
                    
                    
                }
                
            }
            
            
            
            
            
            
        }
    }
}

struct product_description_Previews1: PreviewProvider {
    static var previews: some View {
        product_description()
    }
}

//
//  Setting.swift
//  WooCommerce
//
//  Created by pearl on 12/08/2022.
//

import SwiftUI
import AlertToast
struct Setting: View {
    let screenSize = UIScreen.main.bounds.size;
    @State var loggedIn:Bool = false;
    @State private var fname = "";
    @State private var lname = "";
    @State private var uname = "";
    @State private var password="";
    @State private var cnfrm_password="";
    @State private var pasword_matched_message = ""
    @State private var address = "";
    @State private var phone = "";
    @State private var email="";
    @State private var secured: Bool = true
    @State private var password_toast  = false
     
     @State private var fields_toast = false;
     @State private var fields_toast_message = ""
    @State private var toast = false
    @State private var toast_message = ""
    @State private var register_toast = false
    @State private var register_pressed = false
    @State private var regiter_success_message = ""
    @State private var regiter_fail_message = ""
    @State private var animations = false;
    @State private var CardNumber = "";
    @State private var CvcNumber = "";
    @State private var Card_Exp = "";
    @State private var  selectDate = Date();
    var dateFormatter: DateFormatter {
           let formatter = DateFormatter()
        formatter.dateFormat = "YY/MM/dd"
        formatter.string(from: selectDate)
           return formatter
       }
    var body: some View {
        NavigationView{
            ZStack{
                Color.purple
                    .ignoresSafeArea(.all)
                
                
                
                VStack
                {
                    
                    //
                    
                    //
                    //                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05,alignment: .topLeading)
                    
                    
                    
                    
                    
                    
//                        Image(systemName: "cart.circle")
//
//                            .font(.system(size: 75))
//                            .padding(.bottom,0.1)
//                        Text("WO")
//                            .foregroundColor(Color.black)
//                            .font(.system(size: 35,weight:.bold))
//                        +
//                        Text(" ")
//
//                        +
//                        Text("STORE")
//                            .foregroundColor(Color.white)
//                            .font(.system(size: 35,weight:.bold))
//
                    
                    ZStack{
                        Color.white
                            .frame(width: screenSize.width*0.92, height: screenSize.height*0.78)
                            .cornerRadius(60)
                            .padding(.bottom,70)
                        VStack(spacing:15)
                        {
                            
                            Text("Edit Details")
                                .foregroundColor(Color.purple)
                                .font(.system(size: 20,weight:.bold))
                                .padding([.top],120)
                                .padding([.bottom],15)
                                .padding(.trailing,160)
//                                ScrollView([.horizontal, .vertical]) {
                             
                            VStack{
                                
                                VStack{
                        
                        
                        HStack{
                            
                            Image(systemName: "person.fill")
                            TextField("User Name", text: $uname)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .foregroundColor(.gray)
                            
                        }
                        .padding(.horizontal, 49)
                        .padding(.bottom,2)
                        //                                                .padding(.top, 20)
                        
                        
                        
                        Divider()
                            .padding(.horizontal, 50)
                        
                        }
                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                        ///
                        
                          
                        
                       ////
                        VStack{
                            
                            HStack{
                                
                                Image(systemName: "envelope.fill")
                                TextField("Email Address", text: $email)
                                    .autocapitalization(.none)
                                    .disableAutocorrection(true)
                                    .foregroundColor(.gray)
                                
                            }
                            .padding(.horizontal, 49)
                            .padding(.bottom,2)
                            //                                                .padding(.top, 20)
                            
                            
                            
                            Divider()
                                .padding(.horizontal, 50)
                            
                            
                            
            
                            
                            
                            
                            
                            
                        }
                        .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                        ///
                        
                        
                        VStack{
                            HStack{
                               if secured {
                                   // 2
                                    Image(systemName: "lock.fill")
                                    SecureField("Password", text: $password)
                                    
                                        .foregroundColor(.gray)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                } else {
                                    
                                    // 3
                                    Image(systemName: "lock.fill")
                                    
                                    TextField("Password", text: $password)
                                    
                                        .foregroundColor(.gray)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                }
                         
                                  Button(action: {
                                    self.secured.toggle()
                                }) {
                                    
                                    // 2
                                    if secured {
                                        Image(systemName: "eye.slash.circle")
                                            .font(.system(size:12))
                                            .foregroundColor(Color.black
                                            )
                                    } else {
                                        
                                        Image(systemName: "eye.circle")
                                            .font(.system(size:12))
                                            .foregroundColor(Color.black
                                            )
                                    }
                                }
                                 
                            }
                            
                            .padding(.horizontal, 49)
                            .padding(.bottom,2)
                            //                                    .padding(.top, 20)
                             Divider()
                                .padding(.horizontal, 50)
                            ////////////////////
                            
                            
                        }
                        .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                        
                        
                        VStack{
                            
                            
                            HStack{
                                
                                Image(systemName: "house.fill")
                                TextField("Address", text: $address)
                                    .autocapitalization(.none)
                                    .disableAutocorrection(true)
                                    .foregroundColor(.gray)
                                
                            }
                            .padding(.horizontal, 49)
                            .padding(.bottom,2)
                            //                                                .padding(.top, 20)
                            
                            
                            
                            Divider()
                                .padding(.horizontal, 50)
                            
                            
                            
            
                            
                            
                            
                            
                            
                        }
                        .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                    VStack{
                        
                        
                        HStack{
                            
                            Image(systemName: "phone.fill")
                            TextField("Phone", text: $phone)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                                .foregroundColor(.gray)
                            
                        }
                        .padding(.horizontal, 49)
                        .padding(.bottom,2)
                        //                                                .padding(.top, 20)
                        
                        
                        
                        Divider()
                            .padding(.horizontal, 50)
                        
                        
                        
        
                        
                        
                        
                        
                        
                    }
                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                
                       
                        
                       

                        
                        
                        
                      VStack(spacing:20){
                         
                         
                            
                          Text("Edit Billing Info")
                              .foregroundColor(Color.purple)
                              .font(.system(size: 20,weight:.bold))
                             // .padding([.bottom,.top],10)
                              .padding([.top],15)
                              .padding([.bottom],0)
                              .padding(.trailing,130)
                                
                          Text("Payment Method")
                              
                              .font(.system(size: 18))
                             // .padding([.bottom,.top],10)
                           
                              .padding([.bottom],15)
                              .padding(.trailing,130)
                         
                          VStack{
                  
                  
                  HStack{
                      
                      Image(systemName: "person.fill")
                      TextField("Card Number", text: $CardNumber)
                          .autocapitalization(.none)
                          .disableAutocorrection(true)
                          .foregroundColor(.gray)
                      
                  }
                  .padding(.horizontal, 49)
                  .padding(.bottom,2)
                  //                                                .padding(.top, 20)
                  
                  
                  
                  Divider()
                      .padding(.horizontal, 50)
                  
                  }
              .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                          
                          
                          VStack{
                  
                  
                  HStack{
                      
                      Image(systemName: "person.fill")
                      SecureField("CVC Number", text: $CvcNumber)
                          .autocapitalization(.none)
                          .disableAutocorrection(true)
                          .foregroundColor(.gray)
                      
                  }
                  .padding(.horizontal, 49)
                  .padding(.bottom,2)
                  //                                                .padding(.top, 20)
                  
                  
                  
                  Divider()
                      .padding(.horizontal, 50)
                  
                  }
              .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
//                          VStack {
//                                    Text("Select a date")
//
//
//                                DatePicker(selection: $selectDate, in: ...Date(), displayedComponents: .date) {
//
//                                }
//
//
//
//
//
//                                }.labelsHidden()
                          VStack{


                  HStack{

                      Image(systemName: "person.fill")
                      DatePicker(selection: $selectDate, in: ...Date(), displayedComponents: .date)
                                     {
                                         
                           Text("Select Date")
           
                                     }
                  }
                  .padding(.horizontal, 49)
                  .padding(.bottom,2)
                  //                                                .padding(.top, 20)



                  Divider()
                      .padding(.horizontal, 50)

                  }
              .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                            Button(action:{
                            
                     
                               
                            }
                            ){
                                
                                
                                Text("Update")
                                
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.white)
                                    .padding(.horizontal, 90)
                                    .padding()
                                    .background(Color.purple)
                               

                               
                            }
                        }
                        
                        .padding(.bottom,80)
                                
                            }
                            ///
                           
                            
                        } .padding(.bottom,200)
                        
                    }
                    
                    
                    
                }
                .toast(isPresenting: $password_toast){
                     
                     // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                 AlertToast(displayMode: .alert
                            , type: .regular ,title: pasword_matched_message)
                          
                  
                     //Choose .hud to toast alert from the top of the screen
                     //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                 }
                .animation(.interpolatingSpring(stiffness: 15, damping: 15), value: password_toast)
                .toast(isPresenting: $register_toast){
                     
                     // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                 AlertToast(displayMode: .hud
                            , type: .regular ,title: regiter_success_message)
                          
                  
                     //Choose .hud to toast alert from the top of the screen
                     //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                 }
                .toast(isPresenting: $fields_toast){
                     
                     // `.alert` is the default displayMode
//                                                     AlertToast(displayMode: .banner(.slide), type: .regular, title: pasword_matched_message)
                 AlertToast(displayMode: .hud
                            , type: .regular ,title: fields_toast_message)
                          
                  
                     //Choose .hud to toast alert from the top of the screen
                     //AlertToast(displayMode: .hud, type: .regular, title: "Message Sent!")
                 }

                
                
                
                
            }

            .toolbar {
                ToolbarItem() {
                    HStack(){
                        Button(
                            action:
                                {
                                   
                                    //                                    self.login()
                                    
                                }
                        )
                        {
                            
                            Text("Setting")
                            
                                .foregroundColor(Color.white)
                            
                            
                        }.font(.system(size:25,weight: .bold))
                         
                    }.padding(.trailing,260)
                    
                    
                    
                    
                }
                ToolbarItem(placement: .bottomBar) {
                    
                    HStack(spacing:20){
                        
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Home")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Categories")
                                .font(.system(size:10.7))
                        }
                      
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Orders")
                                .font(.system(size:12))
                        }
                      
                      
                        VStack{
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "person.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        
                       
                        
                    }
                    .foregroundColor(Color.white)
              
                    
                    
                    
                    
                }
                
            }
            
            
            
            
            
            
        }
    }
}

struct Setting_Previews: PreviewProvider {
    static var previews: some View {
        Setting()
    }
}

//import Foundation
//import SwiftUI
//import Swift
//
//
//struct CategoriesListView : View {
//    let phone1 = "telprompt://"
//    @State var loggedIn:Bool = false;
//    @State var uname = ""
//    @State private var password=""
//
// 
//    @State var updated = false
//   
//    @State var model : Categories.VCategories?
//    
//   
// 
//    
//  
//    
//    //@State var index_value : Int;
//    
//  
//    
//   // var dataList : [Task.VTask]
//    var dataList = [Categories.VCategories]()
////    var index : Int
////
//    
// 
//    let screenSize = UIScreen.main.bounds.size;
//    
//    
//    var body: some View{
//        
//        VStack(alignment: .center, spacing: 12.0) {
//            Text(String(model?.id ?? 0))
//                .padding([.top],18)
//                .font(.system(size: 18, weight: .regular, design: .default))
//                .foregroundColor(.blue)
//                .multilineTextAlignment(.center)
//            
//            
//            
//            Text(model?.name ?? "N/A")
//            
//            
//                .font(.system(size: 18, weight: .regular, design: .default))
//                .fixedSize(horizontal: false, vertical: true)
//                .multilineTextAlignment(.center)
////                .foregroundColor(taskTextColor())
//                .frame(maxWidth:screenSize.width)
//    
//        
//            
//            HStack{
//
////                let url2 = URL(string: (phone1+(model?.phone ?? "N/A")))!
//                
////                if(isCallButtonHidden()==false){
////                Link(destination: url2,label: {
////                    Image(systemName: "phone.circle.fill")
////                    .font(.system(size: 35))
////                    .foregroundColor(.white)
////                    .scaledToFit()
////                    .clipped()
////                    .frame(maxWidth:45)
////                    //.isHidden(isCallButtonHidden())
////                    //.isHidden(true)
////                })
////                }
////
//    
//                
//                
//    
//          
//            
//        }.frame(maxWidth:screenSize.width)
//        //    .background(taskBackground())
//            
//        
//            .listRowBackground(Color.gray)
//        
//    }
//    
//          
//
//      
//        
//    }
//    
//    
//
//
//    
//  
//    
//
////    func start_delivery( ){
////
////
////
////            LocationManager.shared.start()
////
////            let task_id = model?.id
////            var phone_num = model?.phone
////            var task_type = model?.type
////
////            let url = URL(string:Constants.Url.startDelivery )
////
////            guard let requestUrl = url else { fatalError() }
////            // Prepare URL Request Object
////            var request = URLRequest(url: requestUrl)
////            request.httpMethod = "POST"
////
////            if(phone_num==nil){
////                phone_num = ""
////            }
////            if (task_type == nil){
////                task_type = "1"
////            }
////
////
////            let postString = "task_id="+task_id!+"&phone="+phone_num!+"&type="+task_type!
////            //2021-12-06
////            // Set HTTP Request Body
////            request.httpBody = postString.data(using:.utf8);
////            // Perform HTTP Request
////            let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in
////
////                // Check for Error
////                if let error = error {
////                    print("Error took place \(error)")
////                    return
////                }
////
////                // Convert HTTP Response Data to a String
////
////                let dataString = String(data: data!, encoding: .utf8)
////
////                print("Response data string:\n \(String(describing: dataString))")
////
////
////
////                //                //create json object from data
////                if( dataString == "Updated Successfully")
////                {
////
////                    self.toast_message = "Delivery Started"
////                    self.toast = true
////                    debugPrint(model?.start_delivery )
////                    //self.color=1
////                    self.deliveryStarted = true
////
////
////                }
////                else{
////                    self.toast_message = "There was an error starting delivery"
////                    self.toast = true
////
////                }
////
////
////            }
////            task.resume()
////
////
////
////
////
//        
//  
//        
//        
//        
//////    }
////    func end_delivery( ){
////        let task_id = model?.id
////
////        LocationManager.shared.stop()
////
////        let url = URL(string:Constants.Url.endDelivery )
////
////        guard let requestUrl = url else { fatalError() }
////        // Prepare URL Request Object
////        var request = URLRequest(url: requestUrl)
////        request.httpMethod = "POST"
////
////
////
////
////        let postString = "task_id="+task_id!
////        //2021-12-06
////        // Set HTTP Request Body
////        request.httpBody = postString.data(using:.utf8);
////        // Perform HTTP Request
////        let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in
////
////            // Check for Error
////            if let error = error {
////                print("Error took place \(error)")
////                return
////            }
////
////            // Convert HTTP Response Data to a String
////
////            let dataString = String(data: data!, encoding: .utf8)
////
////            print("Response data string:\n \(String(describing: dataString))")
////
////
////
////
////
////
////            //                //create json object from data
////            if( dataString == "Updated Successfully")
////            {
////                self.toast_message = "Delivery Ended"
////                self.toast = true
////
////                //self.color=2
////                self.deliveryEnded = true
////
////            }
////            else{
////                self.toast_message = "there was an error ending delivery"
////                self.toast = true
////
////            }
////
////
////        }
////        task.resume()
////
////
////
////    }
////
////
////
////}
//
//
//
//
//}
//
//
//
//struct taskrow_Previews : PreviewProvider {
//    static var previews: some View{
//        CategoriesListView()
//        
//    }
//    
//}

//
//  Products.swift
//  WooCommerce
//
//  Created by pearl on 27/07/2022.
//



import Foundation
class Products: Codable, Identifiable{

   
    var data : [VProducts] = [VProducts]()


    class VProducts:Codable,Identifiable{

        var id:Int?
        var title:String?
        var image:String?
      //  var image:[ImageData] = [ImageData]()
       //var image:[ImageData] = [ImageData]()

//        class ImageData : Codable,Identifiable {
//        // need first item of the array as seen in JSON below
//            let src: String?
//            let value: Int?
//            let condition: Int?
//            let b:Bool?
//
//                init(src: String?, value: Int?, condition: Int?,b:Bool?) {
//                    self.src = src
//                    self.value = value
//                    self.condition = condition
//                    self.b = b
//                }
//        }
       
//        class WeatherItem {
//
//            let title: String?
//            let value: String?
//            let condition: String?
//
//            init(title: String?, value: String?, condition: String?) {
//                self.title = title
//                self.value = value
//                self.condition = condition
//            }
//        }
//        class ImageData: Codable,Identifiable {
//
//            var weatherItems: [WeatherItem] = []
//
//            private enum CodingKeys: String, CodingKey {
//                case weatherItems = "image"
//
//
//        }
//
//    }
        
    }





}



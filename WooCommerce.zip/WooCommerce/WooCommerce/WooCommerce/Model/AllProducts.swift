//
//  AllProducts.swift
//  WooCommerce
//
//  Created by pearl on 29/07/2022.
//

import Foundation
class AllProducts: Codable, Identifiable{

   
    var data : [VAllProducts] = [VAllProducts]()
    var image:String?

    class VAllProducts:Codable, Identifiable{

        var id:Int?
        var name:String?
        var short_description:String?
        var price:String?
        var regular_price:String?
        
      }
 
  
}

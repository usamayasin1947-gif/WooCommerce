//
//  Categories.swift
////  WooCommerce
//
//  Created by pearl on 18/07/2022.

import Foundation
class Categories: Codable, Identifiable{

   
    var categories : [VCategories] = [VCategories]()


    class VCategories:Codable, Identifiable{

        var id:Int?
        var name:String?
        var image : String?





    }
}
//    class VCategories:Codable, Identifiable{
//
//        var id:Int?
//        var name:String?
//        var display:String?
//        var image : VImage?
//
//
//        class VImage: Codable,Identifiable
//        {
//            var id : Int?
//            var name:String?
//            var src:String?
//
//        }
//
//
//
//    }
 
  


//import Foundation
//import SwiftUI
//
//struct VCategories: Codable, Equatable, Identifiable{
//    var id: Int
//    var name: String
//    var images:  ImgProperties
//}
//struct ImgProperties :Codable, Equatable, Identifiable{
//var id = UUID()
//  var src : String
//  var date_created: String
//
//
//}
//struct Categories: Codable {
// let students1: VCategories
// var data : [VCategories] = [VCategories]()
//}

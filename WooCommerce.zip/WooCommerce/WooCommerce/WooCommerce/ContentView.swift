////
//////
//////  ContentView.swift
//////  UI
//////
//////  Created by ES-PEARL on 07/12/2021.
//////
import CoreLocation
import SwiftUI
import UserNotifications

struct ContentView: View {


    let screenSize = UIScreen.main.bounds.size;
    @State var loggedIn:Bool = false;
    @State private var uname = ""
    @State private var password=""
    @State private var secured: Bool = true

    @State private var login_toast = false
    @State private var login_toast_message = ""
    @State private var login_pressed = false
    @State private var animations = false
    
    @State private var show_forget_password = false;
 //   @State private var  forgetpasword  =  ForgetPasword()
    @State private var show_register_view = false;
    
 
 
     func login() {
          
              
              var user_id :String = ""
                              let url = URL(string:Constants.Url.login_api)
                                  guard let requestUrl = url else { fatalError() }
                              
                                  
                                  var request = URLRequest(url: requestUrl)
                                  request.httpMethod = "POST"
          let user_name = UserDefaults.standard.string(forKey: "uname") ?? "";
          let user_password = UserDefaults.standard.string(forKey: "password") ?? "";
                                   let postString = "username="+user_name+"&password="+user_password+"";
                                  request.httpBody = postString.data(using: String.Encoding.utf8);
                                  // Perform HTTP Request
                                  let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                                      
                                      // Check for Error
                                      if let error = error {
                                          print("Error took place \(error)")
                                          return
                                      }
                                      
                                      // Convert HTTP Response Data to a String
                                      if let data = data,
                                         let dataString = String(data: data, encoding: .utf8)
                                      {
                                          print("Response data string:\n \(dataString)")
                                          
                                          //pageManager.pageNo = 1
                                          do {
                                              //                //create json object from dat
                                             // let data = string.data(using: .utf8)!
                                              if let json2 = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                                                  if let status = json2["status"] as? String, status == "ok" {
                                                      
                                                      
                                                      self.loggedIn = true
                                                  
                                                    
                                                      let token = json2["token"]!;
                                                      print("Customer loginesd")
                                                      UserDefaults.standard.set(token, forKey: "token");
                                                      UserDefaults.standard.set(uname, forKey: "user_name");
                                                      UserDefaults.standard.set(password, forKey: "password");
                                                      
                                                  }
                                              }
                                              
                                          } catch let error {
                                              
                                                   self.loggedIn = false
                                                   
                                             if(login_pressed){
                                              self.login_toast = true
                                              self.login_toast_message = "Email and Password does not match!"
                                                   }
                                                   print(error);
                                               

                                               print("*******NOT LOGIN *********")
                                          }
                                          
                                      }
                                      
                                  }
                                  task.resume()
                           
                      }
                      
                      
                  
    
    var body: some View {

    
    

        NavigationView{
            ZStack{
                Color.purple
                    .ignoresSafeArea(.all)



                VStack
                {

                    //

                    //
                    //                    .frame(width: screenSize.width*0.95, height: screenSize.height*0.05,alignment: .topLeading)






                    Image(systemName: "cart.circle")
                        .font(.system(size: 100))
                        .padding(.bottom,0.1)
                    Text("WO")
                        .foregroundColor(Color.black)
                        .font(.system(size: 35,weight:.bold))
                    +
                    Text(" ")

                    +
                    Text("STORE")
                        .foregroundColor(Color.white)
                        .font(.system(size: 35,weight:.bold))


                    ZStack{
                        Color.white
                            .frame(width: screenSize.width*0.92, height: screenSize.height*0.5)
                            .cornerRadius(60)
                            .padding(.bottom,75)
                        VStack(spacing:20)
                        {
                         
                            VStack{

                                HStack{

                                    Image(systemName: "person.fill")
                                    TextField("Username", text: $uname)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                        .foregroundColor(.gray)

                                }
                                .padding(.horizontal, 45)
                                .padding(.bottom,2)
                                //                                                .padding(.top, 20)



                                Divider()
                                    .padding(.horizontal, 46)




                                Button(action:{
                                    
                                    self.show_forget_password = true;
                               
                                   
                                    
                                
                                }
                                )
                                {

                                    Text("Forgot password?")
                                        .font(.system(size:13))
                                        .foregroundColor(Color.gray
                                        )








                                }
                                .padding(.leading,190)
                                .fullScreenCover(isPresented: $show_forget_password) {
                                    ForgetPasword()
                                            }
//                                .sheet(isPresented: $show_forget_password, content: {
//                            ForgetPasword()
//                        })
                          
//                                NavigationLink(destination: ForgetPasword(),isActive: $show_forget_password) {
//                                    EmptyView()
//                                           }




                            }
                            .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)




                            VStack{
                                HStack{

                                    if secured {

                                        // 2
                                        Image(systemName: "lock.fill")

                                        SecureField("Password", text: $password)

                                            .foregroundColor(.gray)
                                            .autocapitalization(.none)
                                            .disableAutocorrection(true)
                                    } else {

                                        // 3
                                        Image(systemName: "lock.fill")

                                        TextField("Password", text: $password)

                                            .foregroundColor(.gray)
                                            .autocapitalization(.none)
                                            .disableAutocorrection(true)
                                    }


                                    Button(action: {
                                        self.secured.toggle()
                                    }) {

                                        // 2
                                        if secured {
                                            Image(systemName: "eye.slash.circle")
                                                .font(.system(size:12))
                                                .foregroundColor(Color.black
                                                )
                                        } else {

                                            Image(systemName: "eye.circle")
                                                .font(.system(size:12))
                                                .foregroundColor(Color.black
                                                )
                                        }
                                    }


                                }

                                .padding(.horizontal, 45)
                                .padding(.bottom,2)
                                //                                    .padding(.top, 20)




                                Divider()
                                    .padding(.horizontal, 46)



                            }
                            .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)






                            //                                        Spacer()

                            VStack(spacing:10){

                                Button(action:{
                                    login_pressed = true
                                     UserDefaults.standard.set(uname, forKey: "uname");
                                     UserDefaults.standard.set(password, forKey: "password");
                                                                      self.login()
                                     
                                     

                                }
                                ){

                                    Text("Login")

                                        .fontWeight(.bold)
                                        .foregroundColor(Color.white)
                                        .padding(.horizontal, 102)
                                        .padding()
                                        .background(Color.purple)


                                }

                                Text("Not a Registered user? Register below now!")
                                    .font(.system(size:13))

                                Button(action:{
                                    self.show_register_view = true
                                    //                                    self.login()

                                }
                                ){

                                    Text("Register")

                                        .fontWeight(.bold)
                                        .foregroundColor(Color.white)
                                        .padding(.horizontal, 90)
                                        .padding()
                                        .background(Color.purple)


                                }
                                .fullScreenCover(isPresented: $show_register_view) {
                                    Register()
                                            }
                            }



                        }.padding(.bottom,75)

                    }



                }




            }


            .toolbar {
                ToolbarItem() {
                    HStack(spacing:270){
                        Button(
                            action:
                                {
                                    login_pressed = true
                                    //                                    self.login()

                                }
                        )
                        {

                            Image(systemName: "menucard.fill")


                                .foregroundColor(Color.white)

                        }




                        Button(
                            action:
                                {
                                    login_pressed = true
                                    //                                    self.login()

                                }
                        )
                        {

                            Image(systemName: "cart.fill")

                                .foregroundColor(Color.white)


                        }


                    }  .font(.system(size:25))




                }
                ToolbarItem(placement: .bottomBar) {

                    HStack(spacing:20){

                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Home")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Categories")
                                .font(.system(size:10.7))
                        }

                        VStack{
                            Image(systemName: "house.fill")
                                .font(.system(size:25))
                            Text("Orders")
                                .font(.system(size:12))
                        }


                        VStack{
                            Image(systemName: "questionmark.circle.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }
                        VStack{
                            Image(systemName: "person.fill")
                                .font(.system(size:25))
                            Text("Help")
                                .font(.system(size:12))
                        }



                    }

                    .foregroundColor(Color.white)



                }

            }






        }



    }
     

}


struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

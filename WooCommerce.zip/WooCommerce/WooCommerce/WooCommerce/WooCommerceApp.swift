//
//  WooCommerceApp.swift
//  WooCommerce
//
//  Created by pearl on 13/07/2022.
//

import SwiftUI

@main
struct WooCommerceApp: App {
    var body: some Scene {
        WindowGroup {
         ContentView()
         // home()
            //products()
            //Register()
            
          // Category_Detail_List()
        }
    }
}

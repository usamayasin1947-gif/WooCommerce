//
//  Constants.swift
//  TNW Driver
//
//  Created by apple on 06/02/2022.
//

import Foundation


struct Constants{
    
    var url_testing = "https://www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_4/";
    var url_production = "https://topsoilsnorthwest.com/tnw_retail_calculator_1_2_4/";
    var url = "https://www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_4/";
   
    
    //not working currently for setting dynamic links, will check the singleton pattern
    
    struct Url{

//        static let login = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/login.php"
//        static let deviceToken = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/deviceToken.php"
//        static let taskList = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/getDriverTasks.php"
//        static let startDelivery = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/startDelivery.php";
//        static let endDelivery = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/endDelivery.php";
//        static let trackDriver = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/trackDriver.php";
//
//        static let Drivers = "https:www.emeraldsoft.uk/projects/hamza/tnw_retail_calculator_1_2_5/web_services/mobile/getDrivers.php";

     
//        static let CategoriesList = "https://emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/list_of_all_categories.php";
        
         static let login_api = "https://emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/login-shop.php";
        static let register_api = "https://www.emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/register.php";
           static let CategoriesList = "https://www.emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/show_all_categories.php";

           
            static let Products_By_Category_Id = "https://www.emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/products_by_category_id.php";
           
           static let allproduct = "https://www.emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/products_by_id.php";
        
        static let forget_password_api =  "https://www.emeraldsoft.uk/projects/2022/woocommerce_api_app/wp-content/plugins/woocommerce_app_template_plugin/forgot-pass.php";
        /////////////////////////
   
          /// code wil move to another function view/////
 
          /// code wil move to another function view/////
         
    }
       
    
}

//
//  fnctions.swift
//  WooCommerce
//
//  Created by pearl on 11/08/2022.
//

import SwiftUI

import Foundation
import SwiftUI
class fnctions: ObservableObject {
  // 1.
    @Published var data1 :[Categories.VCategories] = []
    @Published var product_data :[Products.VProducts] = []
    @Published var product_image_data :[AllProducts.VAllProducts] = []
    @Published var product_image :[AllProducts] = []
    
   
    func loadData() {

              guard let url = URL(string:Constants.Url.CategoriesList)
             else {
                  print("Invalid URL")
                  return
              }
              
            
        
           // Prepare URL Request Object
           var request = URLRequest(url: url)
           request.httpMethod = "POST"



           
           let postString = "";
           request.httpBody = postString.data(using:.utf8);
           // Perform HTTP Request
           let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                   // Check for Error
                   if let error = error {
                       print("Error took place \(error)")
                       return
                   }

                   // Convert HTTP Response Data to a String
               let dataString = String(data: data!, encoding: .utf8)
               print(dataString)

               
               //
               
              //
               
               do {
                   let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
                print(myServiceResponse)
                
              DispatchQueue.main.async {
                 self.data1 = myServiceResponse.categories
             
               
                  


              }
          } catch let error {
             // self.newData = []
              
     //         self.data2 = []
             
          }
               
           }
           task.resume()

       }
    func loadProducts(){
                

                       guard let url = URL(string:Constants.Url.Products_By_Category_Id)
                      else {
                           print("Invalid URL")
                           return
                       }
                       
                     
                 
                    // Prepare URL Request Object
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"


                let category_id = (UserDefaults.standard.string(forKey: "categ_id") ?? "its string")!;
       //          let postString: [String: Any] = [
       //              "id": category_id,
       //
       //          ]
             
                
              let postString = category_id;
               
               //
                request.httpBody = postString.data(using: String.Encoding.utf8);
                    // Perform HTTP Request
                    let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                            // Check for Error
                            if let error = error {
                                print("Error took place \(error)")
                                return
                            }

                            // Convert HTTP Response Data to a String
                        let dataString = String(data: data!, encoding: .utf8)
                        print(dataString)


                        //
                        
                       //
                        
                        do {
                            let myServiceResponse = try JSONDecoder().decode(Products.self,from: data!)
                         print(myServiceResponse)
                          
                         
                       DispatchQueue.main.async {
                          self.product_data = myServiceResponse.data
                      
                        
                           


                       }
                   } catch let error {
                      // self.newData = []
                       
                       self.product_data = []
                      
                   }
                        
                    }
                    task.resume()

                
           }
    
    func loadProductImage(){
         

                guard let url = URL(string:Constants.Url.allproduct)
               else {
                    print("Invalid URL")
                    return
                }
                
              
          
             // Prepare URL Request Object
             var request = URLRequest(url: url)
             request.httpMethod = "POST"


         let product_id = (UserDefaults.standard.string(forKey: "product_id") ?? "its string")!;
//          let postString: [String: Any] = [
//              "id": category_id,
//
//          ]
      
         
       let postString = product_id;
        
        //
         request.httpBody = postString.data(using: String.Encoding.utf8);
             // Perform HTTP Request
             let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                     // Check for Error
                     if let error = error {
                         print("Error took place \(error)")
                         return
                     }

                     // Convert HTTP Response Data to a String
                 let dataString = String(data: data!, encoding: .utf8)
                 print(dataString)


                 //
                 
                //
                 
                 do {
                     let myServiceResponse = try JSONDecoder().decode(AllProducts.self,from: data!)
                  print(myServiceResponse)
                   
                  
                DispatchQueue.main.async {
                   self.product_image_data = myServiceResponse.data
               
                 
                    


                }
            } catch let error {
               // self.newData = []
                
                self.product_image_data = []
               
            }
                 
             }
             task.resume()

         
    }
    init (){
        loadData()
        loadProducts()
        loadProductImage()
        }

    }


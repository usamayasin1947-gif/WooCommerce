//
//  ForgetPasword.swift
//  WooCommerce
//
//  Created by pearl on 15/07/2022.
//

import SwiftUI

struct ForgetPasword: View {
    let screenSize = UIScreen.main.bounds.size;
    @State var loggedIn:Bool = false;
    @State private var email = ""
    @State private var password=""
    @State private var secured: Bool = true

    @State private var toast = false
    @State private var toast_message = ""
    @State private var login_pressed = false
    @State private var animations = false

    func SendResetLink()
       {
           
           guard let url = URL(string:Constants.Url.forget_password_api)
          else {
               print("Invalid URL")
               return
           }
           
         
     
        // Prepare URL Request Object
        var request = URLRequest(url: url)
        request.httpMethod = "POST"



        
           let postString = "email="+self.email;
        request.httpBody = postString.data(using:.utf8);
        // Perform HTTP Request
        let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                // Check for Error
                if let error = error {
                    print("Error took place \(error)")
                    return
                }

                // Convert HTTP Response Data to a String
            let dataString = String(data: data!, encoding: .utf8)
            print(dataString)

            
            //
            
           //
            
            do {
//                let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
//             print(myServiceResponse)
             
           DispatchQueue.main.async {
            //  self.data1 = myServiceResponse.categories
          
            
               


           }
       } catch let error {
          // self.newData = []
           
  //         self.data2 = []
          
       }
            
        }
        task.resume()

           
           
           
       }
       
    var body: some View {

   
            NavigationView{
                ZStack{
                    Color.purple
                            .ignoresSafeArea(.all)
                
                
               
                    VStack
                    {
                        
                        
                        
                        
                        
                        
                        Image(systemName: "lock.fill")
                            .font(.system(size: 100))
                            .padding(.bottom,2)
                       
                        Text("Forgot Password?")
                           
                            .font(.system(size: 20))
                            .padding(.bottom,30)
                        
                        
                        ZStack{
                            Color.white
                                .frame(width: screenSize.width*0.92, height: screenSize.height*0.28)
                               
                                .cornerRadius(60)
                                .padding(.bottom,100)
                            VStack(spacing:20)
                            {
                                
                                VStack{
                                    
                                           HStack{
                                               
                                               Image(systemName: "person.fill")
                                               TextField("Email", text: $email)
                                               .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                                               .disableAutocorrection(true)
                                               .foregroundColor(.gray)
                                               
                                           }
                                           .padding(.horizontal, 40)
                                           .padding(.bottom,2)
                                    
                                           //                                                .padding(.top, 20)
                                           
                    
                                                               
                                           Divider()
                                             .padding(.horizontal, 40)
                                    
                                    
                              
                            
                                   
                         
       
                                        
                                        
                                    }
                                .frame(width: screenSize.width*0.95, height: screenSize.height*0.05)
                                
                 
                                

                                
                     
                                    
                              
                                                
                                
    //                                        Spacer()
                              
                                VStack(spacing:10){
                                    
                                    Button(action:{
                                        self.SendResetLink()
                                 //                                    self.login()

                                                                 }
                                                                 ){

                                                                     Text("Send Reset Link")

                                                                         .fontWeight(.bold)
                                                                         .foregroundColor(Color.white)
                                                                         .padding(.horizontal, 65)
                                                                         .padding()
                                                                         .background(Color.purple)
                                                                         

                                                                 }
                                           
                                     
                                           
                                }.padding(.bottom,120)

               
                                
                            }
                          
                        }
                      
                      
                        
                    }
                 
                    
                      
                    
                }
             
               
                .toolbar {
                    ToolbarItem() {
                        HStack(spacing:270){
                            Button(
                                                            action:
                                                                {
                                                          login_pressed = true
                                                     //                                    self.login()
                                
                                                             }
                                                             )
                                                        {
                                
                                                                Image(systemName: "menucard.fill")
                                                               
                                                                .foregroundColor(Color.white)
                                
                                
                                                      }
                            
                                                  
                            
                         
                                Button(
                                        action:
                                            {
                                      login_pressed = true
                                 //                                    self.login()

                                         }
                                         )
                                    {

                                        Image(systemName: "cart.fill")
                                          
                                            .foregroundColor(Color.white)


                                  }
                            
                            
                        }  .font(.system(size:25))
               
                        
                        
                        
                    }
                    ToolbarItem(placement: .bottomBar) {
                      
                        HStack(spacing:20){
                            
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Home")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Categories")
                                    .font(.system(size:10.7))
                            }
                          
                            VStack{
                                Image(systemName: "house.fill")
                                    .font(.system(size:25))
                                Text("Orders")
                                    .font(.system(size:12))
                            }
                          
                          
                            VStack{
                                Image(systemName: "questionmark.circle.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            VStack{
                                Image(systemName: "person.fill")
                                    .font(.system(size:25))
                                Text("Help")
                                    .font(.system(size:12))
                            }
                            
                           
                            
                        }
                           
                        .foregroundColor(Color.white)
                       
                   
                    }
                    
                }
              
             
               
             
            
                
            }
        }
         
            
    
}

struct ForgetPasword_Previews: PreviewProvider {
    static var previews: some View {
        ForgetPasword()
    }
}

//
//
//import Foundation
//import SwiftUI
//class CategoriesListAPI : ObservableObject{
//    
//    static let shared = CategoriesListAPI()
//    @Published var isLoading : Bool = false
////    @Published var driver_id : String = ""{
////        didSet{
////            fetchData()
////        }
////    } //value not being used at the moment, this is only used to refresh data when driver is changed from admin
////
////     @Published var date = Date(){
////        didSet {
////            fetchData()
////        }
////    }
//
//    
//    var dataList = [Categories.VCategories]()
//
////    init(){
////
////            refreshTimer = Timer.scheduledTimer(withTimeInterval:5, repeats: true, block: { [weak self] (timer) in
////                self?.fetchData()
////                    })
////
////
////    }
//
////    var refreshTimer: Timer?
////
////    func startTimer(){
////        refreshTimer = Timer.scheduledTimer(withTimeInterval:5, repeats: true, block: { [weak self] (timer) in
////            self?.fetchData()
////                })
////    }
////
////    func stopTimer(){
////        refreshTimer = nil
////    }
//
//        func fetchData() {
//
//        self.isLoading = true
//        var user_type :String = ""
//
//        let url = URL(string:Constants.Url.CategoriesList)
//
//        guard let requestUrl = url else { fatalError() }
//        // Prepare URL Request Object
//        var request = URLRequest(url: requestUrl)
//        request.httpMethod = "POST"
//
//
////       let formatter = DateFormatter()
////       formatter.dateFormat = "y-MM-dd"
//        
//
////    let user_id = UserDefaults.standard.string(forKey: "user_id") ?? ""
////     let postString = "id="+user_id+"&date="+formatter.string(from: self.date)
//        
//            let postString = "";
//        request.httpBody = postString.data(using:.utf8);
//        // Perform HTTP Request
//        let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in
//
//                // Check for Error
//                if let error = error {
//                    print("Error took place \(error)")
//                    return
//                }
//
//                // Convert HTTP Response Data to a String
//            let dataString = String(data: data!, encoding: .utf8)
//
//                                      print("Response data string:\n \(dataString)")
//
//                    do {
//
//
//                         let myServiceResponse = try JSONDecoder().decode(Categories.self, from: data!)
//                        DispatchQueue.main.async {
//                            self.dataList = myServiceResponse.data
//                            self.isLoading=true
//
//
//                        }
//
//
//                } catch let error {
//                    self.dataList = []
//                    self.isLoading = true
//                }
//
//        }
//        task.resume()
//
//    }
//
//}

//
//  products.swift
//  WooCommerce
//
//  Created by pearl on 27/07/2022.
//

import SwiftUI
import SDWebImage
import SDWebImageSwiftUI
struct products: View {
    @State var product_data :[Products.VProducts] = []
    @State var all_product_data :[AllProducts.VAllProducts] = []
     
    func loadAllProducts(){
         

        guard let url = URL(string:Constants.Url.allproduct)
               else {
                    print("Invalid URL")
                    return
                }
                
              
          
             // Prepare URL Request Object
             var request = URLRequest(url: url)
             request.httpMethod = "POST"


         let product_id = (UserDefaults.standard.string(forKey: "product_id") ?? "its string")!;
//          let postString: [String: Any] = [
//              "id": category_id,
//
//          ]
      
         
       let postString = product_id;
        
        //
         request.httpBody = postString.data(using: String.Encoding.utf8);
             // Perform HTTP Request
             let task = URLSession.shared.dataTask(with: request) {  (data, response, error) in

                     // Check for Error
                     if let error = error {
                         print("Error took place \(error)")
                         return
                     }

                     // Convert HTTP Response Data to a String
                 let dataString = String(data: data!, encoding: .utf8)
                 print(dataString)

                 
                 //
                 
                //
                 
                 do {
                     let myServiceResponse = try JSONDecoder().decode(AllProducts.self, from: data!)
                  print(myServiceResponse)
                  
                DispatchQueue.main.async {
                   self.all_product_data = myServiceResponse.data
               
                 
                    


                }
            } catch let error {
               // self.newData = []
                
       //         self.data2 = []
               
            }
                 
             }
             task.resume()

         
    }
    
    var body: some View {
       
    
        NavigationView{
            
            HStack{
             
                
                ScrollView(.horizontal,showsIndicators: true){
                    
                HStack{
                ForEach(product_data, id: \.id) { product in
               
                 // Text(item.image?.src ?? "")

                   
                        
                        Button {
                                 print("Image tapped!")
                            loadAllProducts()
                             } label: {
                                 
          VStack{

             
             Text(product.title ?? "No text")
             .font(.system(size:10))
               }
                             }

    }
                }.padding()
                        
                     //  .onAppear(perform: loadProducts)
                    
               }.frame(height: 100)
                
                
                
                
                
            }.navigationTitle("Trending Now")
            
        }
    }
}

struct products_Previews1: PreviewProvider {
    static var previews: some View {
        products()
    }
}

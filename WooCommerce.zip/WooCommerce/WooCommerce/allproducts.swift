//
//  allproducts.swift
//  WooCommerce
//
//  Created by pearl on 29/07/2022.
//

import SwiftUI
import SDWebImage
import SDWebImageSwiftUI
struct allproducts: View {
    @State var all_products_data :[AllProducts.VAllProducts] = []
    var body: some View {
       
        NavigationView{
            
//            HStack{
//
//
//                ScrollView(.horizontal,showsIndicators: true){
//
//                HStack{
//                ForEach(all_products_data, id: \.id) { allproducts in
//
//                 // Text(allproducts.image?.src ?? "")
//
//
//
//                        Button {
//                                 print("Image tapped!")
//
//                             } label: {
//
//          VStack{
//
//
//             Text(allproducts.title ?? "No text")
//             .font(.system(size:10))
//               }
//                             }
//
//    }
//                }.padding()
//
//                     //  .onAppear(perform: loadProducts)
//
//               }.frame(height: 100)
//
//
//
//
//
//            }
            
        }
    }
}

struct allproducts_Previews: PreviewProvider {
    static var previews: some View {
        allproducts()
    }
}
